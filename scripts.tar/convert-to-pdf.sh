#!/bin/sh

#RENDITION_SERVER_URL=http://rendition-nginx:8192/rs
RENDITION_SERVER_URL=http://rendition-server:8192/rs
SRC_MIME_TYPE=application/vnd.openxmlformats-officedocument.wordprocessingml.document
DEST_MIME_TYPE=application/pdf
SRC_FILE=/tmp/msword.docx
DEST_FILE=/tmp/msword.pdf


DOC_URL=$(curl -s -i -X POST -H "Content-Type: ${SRC_MIME_TYPE}" -d /tmp/msword.docx  ${RENDITION_SERVER_URL}/upload | sed -n 's/^Link: <\(http:\/\/.*\)>; rel="convert".*$/\1/p')
if [ -n "${DOC_URL}" ]
then
  curl -s -i -X PUT -H "Accept: ${DEST_MIME_TYPE}" -H "Content-Type: application/json" -d '{ "pdf.compliance" : "PDF/A-2b" }' -o ${DEST_FILE} "${DOC_URL}"
  curl -s -X DELETE ${DOC_URL%/*}
fi
