#!/bin/sh

#APPLICATION_SERVER_URL=http://application-server:8080/
APPLICATION_SERVER_URL=http://k8s-master01:80/
APPLICATION_INSTANCE=nscalealinst
USERNAME=admin
PASSWORD=admin

URL="${APPLICATION_SERVER_URL}${APPLICATION_INSTANCE}/rest/usermanagement/domain/nscale/users/admin.vcard"
curl --silent --basic --user ${USERNAME}:${PASSWORD} "$URL"

